package com.example.springbootflywaydemo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringbootflywaydemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringbootflywaydemoApplication.class, args);
	}

}
